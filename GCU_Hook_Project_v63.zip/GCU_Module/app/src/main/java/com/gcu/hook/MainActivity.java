package com.gcu.hook;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/**
 * v22：底部三页
 *   第1页 开启   —— 总开关 / 全局模式 / 应用列表
 *   第2页 帧率   —— 大字展示渲染帧率与面板刷新，说人话
 *   第3页 关于   —— 使用说明 + 日志（可清空 / 导出）
 */
public class MainActivity extends Activity {

    private static final String PREFS = "config";
    private static final String LOG_PATH   = "/storage/emulated/0/GCU/gcu.log";
    private static final String STATE_PATH = "/storage/emulated/0/GCU/fps.json";
    private static final String EXPORT_DIR = "/storage/emulated/0/Download";

    private Switch swMaster;
    private Switch swGlobal;
    private TextView status;
    private TextView fpsBig;
    private TextView fpsDetail;
    private TextView logView;

    private LinearLayout pageHome;
    private LinearLayout pageFps;
    private LinearLayout pageAbout;
    private TextView tbHome, tbFps, tbAbout;

    // ---------------- 视觉：与图标同调（深紫黑 + 金） ----------------
    private static final int C_BG_TOP = 0xFF1B1533;
    private static final int C_BG_BOT = 0xFF0D0A16;
    private static final int C_CARD   = 0xFF241C3A;
    private static final int C_CARD_2 = 0xFF2E2547;
    private static final int C_GOLD   = 0xFFFFC43D;
    private static final int C_TEXT   = 0xFFFFFFFF;
    private static final int C_TEXT_2 = 0xB3FFFFFF;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable roundBg(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable roundBgStroke(int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable d = roundBg(color, radiusDp);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    /** 主按钮=金色底深字；次按钮=深底白字带描边 */
    private TextView makeAction(String text, boolean primary) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(9), dp(16), dp(9));
        if (primary) {
            b.setTextColor(0xFF1B1533);
            b.setBackground(roundBg(C_GOLD, 10));
        } else {
            b.setTextColor(C_TEXT);
            b.setBackground(roundBgStroke(C_CARD_2, 10, 0x33FFFFFF, 1));
        }
        b.setClickable(true);
        return b;
    }

    private int currentPage = 0;
    private boolean ready = false;

    private AppAdapter appAdapter;
    private final ArrayList<AppItem> items = new ArrayList<>();
    private final HashSet<String> checked = new HashSet<>();

    private int pad;
    private int iconSize;

    private final ArrayList<Float> perfdSamples = new ArrayList<>();

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable fpsTicker = new Runnable() {
        @Override
        public void run() {
            refreshFps();
            if (currentPage == 1) handler.postDelayed(this, 2000);
        }
    };

    static class AppItem {
        String pkg;
        String label;
        Drawable icon;
        AppItem(String p, String l, Drawable i) {
            pkg = p; label = l; icon = i;
        }
    }

    private boolean mainBuilt = false;

    /** Android 11+ 需要「所有文件访问权限」才能写配置和日志 */
    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            return Environment.isExternalStorageManager();
        } catch (Throwable t) {
            return true;
        }
    }

    private void openStorageSettings() {
        try {
            Intent it = new Intent(
                    android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            it.setData(Uri.parse("package:" + getPackageName()));
            startActivity(it);
        } catch (Throwable t) {
            try {
                startActivity(new Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Throwable ignored) { }
        }
    }

    /** 引导页：必须先给权限，否则配置写不出去 */
    private View buildGuide() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(28), dp(28), dp(28), dp(28));
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{C_BG_TOP, C_BG_BOT}));

        TextView title = new TextView(this);
        title.setText("需要一项权限");
        title.setTextSize(22);
        title.setTextColor(C_TEXT);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView desc = new TextView(this);
        desc.setText("本模块的配置和日志保存在：\n/storage/emulated/0/GCU/\n\n"
                + "请授予「所有文件访问权限」。\n"
                + "没这个权限，勾选的游戏存不下来，模块不会生效。");
        desc.setTextSize(13);
        desc.setTextColor(C_TEXT_2);
        desc.setGravity(Gravity.CENTER);
        desc.setLineSpacing(dp(2), 1.15f);
        desc.setPadding(0, dp(18), 0, dp(26));
        box.addView(desc);

        TextView btn = makeAction("去授权", true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStorageSettings();
            }
        });
        box.addView(btn, new LinearLayout.LayoutParams(
                dp(180), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView tip2 = new TextView(this);
        tip2.setText("授权完成后返回本页即可");
        tip2.setTextSize(11);
        tip2.setTextColor(C_TEXT_2);
        tip2.setGravity(Gravity.CENTER);
        tip2.setPadding(0, dp(14), 0, 0);
        box.addView(tip2);

        return box;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!hasStoragePermission()) {
            setContentView(buildGuide());
            return;
        }
        setupMainUi();
    }

    private void setupMainUi() {
        mainBuilt = true;

        float d = getResources().getDisplayMetrics().density;
        pad = (int) (14 * d);
        iconSize = (int) (44 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{C_BG_TOP, C_BG_BOT}));

        FrameLayout container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        pageHome = buildHome();
        pageFps = buildFps();
        pageAbout = buildAbout();
        container.addView(pageHome);
        container.addView(pageFps);
        container.addView(pageAbout);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(8), dp(6), dp(8), dp(10));
        bar.setBackgroundColor(0xFF120E20);
        tbHome = makeTab("开启");
        tbFps = makeTab("帧率");
        tbAbout = makeTab("关于");
        bar.addView(tbHome);
        bar.addView(tbFps);
        bar.addView(tbAbout);
        root.addView(bar);

        setContentView(root);

        loadApps();
        appLog("env " + envInfo());
        loadPrefs();
        ready = true;
        updateStatus();
        showPage(0);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (ready) save();
        handler.removeCallbacks(fpsTicker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从授权页返回后，如果已授权且主界面还没建，就建
        if (!mainBuilt && hasStoragePermission()) {
            setupMainUi();
            return;
        }
        if (currentPage == 1) handler.post(fpsTicker);
    }

    // ------------------------------------------------------------
    // 底部标签
    // ------------------------------------------------------------

    private TextView makeTab(String name) {
        TextView b = new TextView(this);
        b.setText(name);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(10), 0, dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(4);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        b.setClickable(true);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == tbHome) showPage(0);
                else if (v == tbFps) showPage(1);
                else showPage(2);
            }
        });
        return b;
    }

    private void styleTab(TextView t, boolean on) {
        if (t == null) return;
        if (on) {
            t.setTextColor(0xFF1B1533);
            t.setBackground(roundBg(C_GOLD, 12));
        } else {
            t.setTextColor(C_TEXT_2);
            t.setBackground(roundBg(0x14FFFFFF, 12));
        }
    }

    private void showPage(int page) {
        currentPage = page;
        pageHome.setVisibility(page == 0 ? View.VISIBLE : View.GONE);
        pageFps.setVisibility(page == 1 ? View.VISIBLE : View.GONE);
        pageAbout.setVisibility(page == 2 ? View.VISIBLE : View.GONE);
        styleTab(tbHome, page == 0);
        styleTab(tbFps, page == 1);
        styleTab(tbAbout, page == 2);

        handler.removeCallbacks(fpsTicker);
        if (page == 1) {
            refreshFps();
            handler.postDelayed(fpsTicker, 2000);
        } else if (page == 2) {
            refreshLog();
        } else {
            updateStatus();
        }
    }

    // ------------------------------------------------------------
    // 第1页：开启
    // ------------------------------------------------------------

    private LinearLayout buildHome() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Q芯超分解锁 v63");
        title.setTextSize(20);
        title.setTextColor(C_TEXT);
        page.addView(title);

        TextView tip = new TextView(this);
        tip.setText("勾选哪个游戏，就对哪个生效。");
        tip.setTextSize(11);
        tip.setTextColor(C_TEXT_2);
        tip.setPadding(0, dp(6), 0, dp(10));
        page.addView(tip);

        status = new TextView(this);
        status.setText("读取中...");
        status.setTextSize(12);
        status.setTextColor(C_GOLD);
        status.setPadding(0, 0, 0, dp(4));
        page.addView(status);

        LinearLayout rowM = makeSwitchRow("总开关", "关闭后所有 Hook 不生效", true,
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        if (ready) save();
                    }
                });
        swMaster = (Switch) rowM.getTag();
        LinearLayout.LayoutParams rm = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rm.topMargin = dp(8);
        page.addView(rowM, rm);

        LinearLayout rowG = makeSwitchRow("全局模式", "不看列表，所有 App 都放行", false,
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton b, boolean v) {
                        if (ready) save();
                    }
                });
        swGlobal = (Switch) rowG.getTag();
        LinearLayout.LayoutParams rg = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rg.topMargin = dp(6);
        page.addView(rowG, rg);

        LinearLayout allRow = new LinearLayout(this);
        allRow.setOrientation(LinearLayout.HORIZONTAL);
        allRow.setPadding(0, dp(8), 0, 0);
        TextView allBtn = makeAction("全选 / 取消全选", false);
        allBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean allOn = !items.isEmpty() && checked.size() >= items.size();
                if (allOn) {
                    checked.clear();
                } else {
                    for (AppItem it2 : items) checked.add(it2.pkg);
                }
                if (appAdapter != null) appAdapter.notifyDataSetChanged();
                if (ready) save(); else updateStatus();
            }
        });
        allRow.addView(allBtn, new LinearLayout.LayoutParams(
                dp(150), ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(allRow);

        ListView lv = new ListView(this);
        appAdapter = new AppAdapter();
        lv.setAdapter(appAdapter);
        lv.setDivider(null);
        lv.setDividerHeight(dp(6));
        lv.setClipToPadding(false);
        lv.setPadding(0, dp(8), 0, dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = pad / 2;
        page.addView(lv, lp);

        return page;
    }

    // ------------------------------------------------------------
    // 第2页：帧率（说人话）
    // ------------------------------------------------------------

    private LinearLayout buildFps() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(pad * 2, pad * 2, pad * 2, pad * 2);

        TextView head = new TextView(this);
        head.setText("实时帧率");
        head.setTextSize(14);
        head.setTextColor(C_TEXT_2);
        page.addView(head);

        fpsBig = new TextView(this);
        fpsBig.setTextSize(46);
        fpsBig.setTextColor(C_GOLD);
        fpsBig.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        fpsBig.setPadding(0, dp(10), 0, dp(14));
        fpsBig.setText("--");
        page.addView(fpsBig);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundBg(C_CARD, 14));

        fpsDetail = new TextView(this);
        fpsDetail.setTextSize(13);
        fpsDetail.setTextColor(C_TEXT);
        fpsDetail.setLineSpacing(dp(3), 1.1f);
        card.addView(fpsDetail);

        page.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView refresh = makeAction("立即刷新", true);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshFps();
            }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                dp(150), ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(20);
        page.addView(refresh, blp);

        return page;
    }

    private void refreshFps() {
        float nativeFps = readStateFloat("native");
        float smoothFps = readStateFloat("smooth");
        float shown = smoothFps > 0 ? smoothFps : nativeFps;
        float hz = readRefreshRate();
        final float sysFps = readPerfdFps();
        if (sysFps > 0) {
            perfdSamples.add(sysFps);
            while (perfdSamples.size() > 60) perfdSamples.remove(0);
        }

        if (shown > 0) {
            fpsBig.setText(String.format(Locale.US, "%.0f 帧", shown));
        } else {
            fpsBig.setText("-- 帧");
        }

        StringBuilder sb = new StringBuilder();
        sb.append("游戏自己画出来的帧数：")
                .append(nativeFps > 0 ? String.format(Locale.US, "%.1f", nativeFps) : "读不到")
                .append("\n");
        sb.append("去噪后的有效帧率：")
                .append(smoothFps > 0 ? String.format(Locale.US, "%.0f", smoothFps) : "读不到")
                .append("\n");
        if (!perfdSamples.isEmpty()) {
            float min = perfdSamples.get(0);
            float max = perfdSamples.get(0);
            float sum = 0f;
            int diff = 0;
            float first = perfdSamples.get(0);
            for (int i = 0; i < perfdSamples.size(); i++) {
                float v = perfdSamples.get(i);
                if (v < min) min = v;
                if (v > max) max = v;
                sum += v;
                if (Math.abs(v - first) > 0.5f) diff++;
            }
            float avg = sum / perfdSamples.size();
            sb.append("系统记录帧率（取样 ").append(perfdSamples.size()).append(" 次）\n");
            sb.append("  当前 ").append(String.format(Locale.US, "%.1f", sysFps))
                    .append("   最小 ").append(String.format(Locale.US, "%.1f", min))
                    .append("   最大 ").append(String.format(Locale.US, "%.1f", max))
                    .append("\n");
            sb.append("  平均 ").append(String.format(Locale.US, "%.1f", avg))
                    .append("   波动 ").append(diff).append(" 次\n");
            boolean real = (max - min) > 0.5f;
            sb.append("  判定：").append(real
                    ? "真实测量值 ✔（会波动）"
                    : "恒定不变，疑似上限或刷新率").append("\n\n");
        } else {
            sb.append("系统记录帧率（perfd）：读不到\n\n");
        }
        sb.append("屏幕实际刷新：")
                .append(hz > 0 ? String.format(Locale.US, "%.0f Hz", hz) : "读不到")
                .append("\n\n");

        if (shown > 0 && hz > 0) {
            if (hz >= shown * 1.5f) {
                sb.append("结论：插帧大概率在工作。\n")
                        .append("屏幕刷新次数明显高于游戏画的帧数，说明中间有帧被补出来。");
            } else if (Math.abs(hz - shown) < 8f) {
                sb.append("结论：现在没有插帧。\n")
                        .append("屏幕刷新次数和游戏画的帧数差不多，没有多出来的帧。");
            } else {
                sb.append("结论：数据异常，需要人工判断。");
            }
        } else {
            sb.append("先打开游戏，进入 Q1 专区一次，数据才会出现。");
        }

        fpsDetail.setText(sb.toString());
    }

    // ------------------------------------------------------------
    // 第3页：关于（说明 + 日志）
    // ------------------------------------------------------------

    private LinearLayout buildAbout() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(pad, pad, pad, pad);

        TextView head = new TextView(this);
        head.setText("使用说明");
        head.setTextSize(14);
        head.setTextColor(C_TEXT_2);
        page.addView(head);

        ScrollView helpScroll = new ScrollView(this);
        TextView help = new TextView(this);
        help.setText(HELP_TEXT);
        help.setTextSize(11);
        help.setTextColor(C_TEXT);
        help.setLineSpacing(dp(2), 1.1f);
        help.setPadding(dp(16), dp(14), dp(16), dp(14));
        help.setBackground(roundBg(C_CARD, 14));
        helpScroll.addView(help);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        hlp.topMargin = dp(8);
        page.addView(helpScroll, hlp);

        TextView logHead = new TextView(this);
        logHead.setText("运行日志（排查问题用，看不懂可以忽略）");
        logHead.setTextSize(11);
        logHead.setTextColor(C_TEXT_2);
        logHead.setPadding(0, dp(12), 0, dp(6));
        page.addView(logHead);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        TextView bRefresh = makeAction("刷新", false);
        bRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { refreshLog(); }
        });
        bar.addView(bRefresh, tabLp());

        TextView bClear = makeAction("清空", false);
        bClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { clearLog(); }
        });
        bar.addView(bClear, tabLp());

        TextView bExport = makeAction("导出", true);
        bExport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { exportLog(); }
        });
        bar.addView(bExport, tabLp());

        page.addView(bar);

        LinearLayout bar2 = new LinearLayout(this);
        bar2.setOrientation(LinearLayout.HORIZONTAL);

        TextView bProbe = makeAction("系统探测(root)", false);
        bProbe.setBackground(roundBgStroke(C_CARD_2, 10, 0x44FFC43D, 1));
        bProbe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { runProbe(); }
        });
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p2.topMargin = dp(8);
        p2.rightMargin = dp(3);
        bar2.addView(bProbe, p2);

        TextView bRestore = makeAction("还原帧率表", true);
        bRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { requestRestore(); }
        });
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p3.topMargin = dp(8);
        p3.leftMargin = dp(3);
        bar2.addView(bRestore, p3);

        page.addView(bar2);

        logView = new TextView(this);
        logView.setTextSize(9);
        logView.setTypeface(Typeface.MONOSPACE);

        logView.setTextColor(0xFF9FE8B0);
        logView.setPadding(dp(14), dp(12), dp(14), dp(12));
        logView.setBackground(roundBg(0xFF141020, 14));

        ScrollView sv = new ScrollView(this);
        sv.addView(logView);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = dp(4);
        page.addView(sv, lp);

        return page;
    }

    private LinearLayout.LayoutParams tabLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(3);
        lp.rightMargin = dp(3);
        return lp;
    }

    private void refreshLog() {
        if (logView != null) logView.setText(readLogTail(300));
    }

    private String readLogTail(int maxLines) {
        File f = new File(LOG_PATH);
        if (!f.exists()) {
            return "（暂无日志）\n路径：" + LOG_PATH
                    + "\n\n如果一直为空，请确认：\n"
                    + "1. 已授予「所有文件访问权限」\n"
                    + "2. 模块已启用，作用域含游戏魔盒\n"
                    + "3. 强制停止过游戏魔盒并重新打开";
        }
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "r");
            long len = raf.length();
            int size = (int) Math.min(len, 48 * 1024L);
            byte[] buf = new byte[size];
            raf.seek(len - size);
            raf.readFully(buf);
            String[] lines = new String(buf, "UTF-8").split("\n");
            int start = Math.max(0, lines.length - maxLines);
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < lines.length; i++) sb.append(lines[i]).append('\n');
            return sb.toString();
        } catch (Throwable t) {
            return "读取日志失败：" + t;
        } finally {
            try { if (raf != null) raf.close(); } catch (Throwable ignored) { }
        }
    }

    private void clearLog() {
        try {
            FileOutputStream fos = new FileOutputStream(new File(LOG_PATH), false);
            fos.close();
            Toast.makeText(this, "日志已清空", Toast.LENGTH_SHORT).show();
            refreshLog();
        } catch (Throwable t) {
            Toast.makeText(this, "清空失败：" + t, Toast.LENGTH_LONG).show();
        }
    }

    private void exportLog() {
        try {
            File src = new File(LOG_PATH);
            if (!src.exists()) {
                Toast.makeText(this, "没有日志可导出", Toast.LENGTH_SHORT).show();
                return;
            }
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File dir = new File(EXPORT_DIR);
            if (!dir.exists()) dir.mkdirs();
            File dst = new File(dir, "gcu_log_" + ts + ".txt");
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(dst);
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.flush();
            } finally {
                try { in.close(); } catch (Throwable ignored) { }
                try { out.close(); } catch (Throwable ignored) { }
            }
            Toast.makeText(this, "已导出：" + dst.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Toast.makeText(this, "导出失败：" + t, Toast.LENGTH_LONG).show();
        }
    }

    /** 读高通 perfd 记录的当前帧率：/data/vendor/perfd/current_fps（需 root） */
    private float readPerfdFps() {
        try {
            String s = suExec("cat /data/vendor/perfd/current_fps 2>/dev/null").trim();
            if (s.length() == 0) return -1f;
            int nl = s.indexOf('\n');
            if (nl > 0) s = s.substring(0, nl).trim();
            return Float.parseFloat(s);
        } catch (Throwable t) {
            return -1f;
        }
    }

    // ------------------------------------------------------------
    // root 系统探测：把服务清单与节点清单写成 probe.txt
    // ------------------------------------------------------------

    private static final String PROBE_PATH = "/storage/emulated/0/GCU/probe.txt";

    /** 一键还原：写一个标记文件，模块下次注入时把我们写过的帧率条目删掉 */
    private void requestRestore() {
        boolean ok = writeText("/storage/emulated/0/GCU/restore.flag", "1");
        if (ok) {
            Toast.makeText(this,
                    "已请求还原。打开一次游戏魔盒的 Q1 专区后生效。",
                    Toast.LENGTH_LONG).show();
            appLog("requestRestore ok");
        } else {
            Toast.makeText(this, "写入失败，请确认已授予所有文件访问权限",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void runProbe() {
        Toast.makeText(this, "开始探测，请授予 root 权限…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String[] cmds = {
                        "service list | grep -iE 'vivo|game|pq|memc|mfr|q1|display'",
                        "dumpsys -l | grep -iE 'vivo|game|pq|memc|mfr|q1|display'",
                        "ls /sys/kernel/debug/dri/0",
                        "ls /sys/kernel/debug/drm",
                        "ls /sys/class/misc",
                        "ls /proc | grep -iE 'vivo|game|pq|memc|q1|disp'",
                        "ls /dev | grep -iE 'vivo|game|pq|q1|disp'",
                        "cat /sys/class/drm/card0-DSI-1/modes",
                        "cat /data/vendor/perfd/current_fps",
                        "ls /data/vendor/perfd",
                        "head -c 2000 /data/vendor/perfd/default_values"
                };
                StringBuilder sb = new StringBuilder();
                sb.append("# probe at ").append(System.currentTimeMillis()).append("\n");
                for (String c : cmds) {
                    sb.append("\n===== ").append(c).append(" =====\n");
                    sb.append(suExec(c));
                }
                final boolean ok = writeText(PROBE_PATH, sb.toString());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,
                                ok ? "探测完成，已写入 probe.txt" : "探测结果写入失败",
                                Toast.LENGTH_LONG).show();
                        refreshLog();
                    }
                });
            }
        }).start();
    }

    private static String suExec(String cmd) {
        StringBuilder out = new StringBuilder();
        Process p = null;
        BufferedReader br = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            p.getOutputStream().close();
            br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            String line;
            long t0 = System.currentTimeMillis();
            while ((line = br.readLine()) != null) {
                out.append(line).append('\n');
                if (System.currentTimeMillis() - t0 > 8000L) break;
            }
            p.waitFor();
            if (out.length() == 0) out.append("(无输出)\n");
        } catch (Throwable t) {
            out.append("ERR ").append(t).append('\n');
        } finally {
            try { if (br != null) br.close(); } catch (Throwable ignored) { }
            try { if (p != null) p.destroy(); } catch (Throwable ignored) { }
        }
        return out.toString();
    }

    private static boolean writeText(String path, String content) {
        FileOutputStream fos = null;
        try {
            File f = new File(path);
            File d = f.getParentFile();
            if (d != null && !d.exists()) d.mkdirs();
            fos = new FileOutputStream(f, false);
            fos.write(content.getBytes("UTF-8"));
            fos.flush();
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) { }
        }
    }

    // ------------------------------------------------------------
    // 帧率读取
    // ------------------------------------------------------------

    private float readStateFloat(String key) {
        try {
            File f = new File(STATE_PATH);
            if (!f.exists()) return -1f;
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            try {
                int size = (int) Math.min(raf.length(), 8192L);
                byte[] buf = new byte[size];
                raf.readFully(buf);
                String s = new String(buf, "UTF-8");
                int i = s.indexOf("\"" + key + "\":");
                if (i < 0) return -1f;
                int j = i + key.length() + 3;
                int k = j;
                while (k < s.length() && "-0123456789.".indexOf(s.charAt(k)) >= 0) k++;
                if (k <= j) return -1f;
                return Float.parseFloat(s.substring(j, k));
            } finally {
                raf.close();
            }
        } catch (Throwable t) {
            return -1f;
        }
    }

    private float readRefreshRate() {
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm == null) return -1f;
            return wm.getDefaultDisplay().getRefreshRate();
        } catch (Throwable t) {
            return -1f;
        }
    }

    // ------------------------------------------------------------
    // 原有逻辑：开关行 / 应用列表 / 存取
    // ------------------------------------------------------------

    private LinearLayout makeSwitchRow(String name, String desc, boolean def,
                                       CompoundButton.OnCheckedChangeListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        row.setBackground(roundBg(C_CARD, 12));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView t1 = new TextView(this);
        t1.setText(name);
        t1.setTextSize(15);
        texts.addView(t1);

        TextView t2 = new TextView(this);
        t2.setText(desc);
        t2.setTextSize(11);
        t2.setAlpha(0.6f);
        texts.addView(t2);

        row.addView(texts);

        Switch sw = new Switch(this);
        sw.setChecked(def);
        sw.setOnCheckedChangeListener(l);
        row.addView(sw);

        row.setTag(sw);
        return row;
    }

    private static final String HELP_TEXT =
            "它做什么\n"
            + "让「你勾选的应用」也能用上 vivo 游戏魔盒 Q1 专区的两个功能：\n"
            + "超级分辨率（超分）和超级帧率（超帧）。\n"
            + "没勾选的应用 = 完全零干预。\n\n"

            + "使用步骤（顺序不能错）\n"
            + "1. LSPosed 里启用本模块\n"
            + "2. 作用域勾选「游戏魔盒」← 漏这步一切都不会发生\n"
            + "3. 打开本 App，在「开启」页勾选要解锁的应用\n"
            + "4. 强制停止游戏魔盒让它重新加载：\n"
            + "    su -c 'am force-stop com.vivo.gamecube'\n"
            + "5. 进游戏，滑出侧边栏 → Q芯专区\n\n"

            + "★ 重要：插帧时必须开 144Hz\n"
            + "设置 → 显示与亮度 → 屏幕刷新率 → 选 144Hz\n"
            + "原因有两条，都是硬性的：\n"
            + "· 游戏魔盒第一道检查就是「刷新率是不是 60」，\n"
            + "  是 60 直接拒绕，连机会都不给\n"
            + "· 插帧的目标帧率必须等于屏幕刷新率，\n"
            + "  144Hz 的屏才能补到 144 帧\n"
            + "如果屏幕停在 60Hz，最多只能 30→60，基本没意义。\n\n"

            + "档位是怎么定的\n"
            + "插帧的原理是「两张真实帧中间夹一张插值帧」，所以：\n"
            + "  目标帧率 = 压缩帧率 × 2      只能 2 倍，3 倍做不到\n"
            + "  目标帧率 ≤ 屏幕峰值刷新率    否则显示不出来\n"
            + "由此只存在四种合法组合：\n"
            + "  压 30 → 补  60\n"
            + "  压 45 → 补  90\n"
            + "  压 60 → 补 120\n"
            + "  压 72 → 补 144\n"
            + "模块每 10 秒测一次游戏帧率，在「压缩值不超过实测帧率」\n"
            + "且「压缩值不超过刷新率的一半」里取最大的一档。\n"
            + "一档都不满足（实测低于 30）就用最低档，永不主动关闭。\n\n"

            + "举例（144Hz 屏）\n"
            + "  游戏跑 60 帧 → 压 60 → 补 120\n"
            + "  游戏跑 90 帧 → 压 72 → 补 144（压到 72 才能 2 倍到 144）\n"
            + "  游戏跑 30 帧 → 压 30 → 补  60\n\n"

            + "超级分辨率\n"
            + "· Q1 专区出现「超级分辨率」卡片\n"
            + "· 可选 原始分辨率 / 超高分辨率\n"
            + "· 选择会保存，下次进游戏自动沿用\n\n"

            + "超级帧率\n"
            + "· 卡片里选「极致帧率」即为开启\n"
            + "· 原生帧率校验已绕过，不用把游戏帧率设成特定值\n"
            + "· 帧率变化不会把开关关掉（只拦自动关闭，\n"
            + "  你手动切回「原始帧率」依然有效）\n\n"

            + "怎么判断有没有生效\n"
            + "插帧效果软件测不出来——它发生在 GPU 合成之后、上屏之前，\n"
            + "所有帧率计数看到的都是插帧前的数字。只能靠肉眼看画面。\n"
            + "可以查的两个状态位：\n"
            + "  su -c 'settings get system gamecube_frame_interpolation'\n"
            + "    出现 1:3:xxx:72:144 之类的值 = 命令已下发\n"
            + "  su -c 'settings get system nova_memc_status'\n"
            + "    变成 1 = 系统把 MEMC 切过去了\n\n"

            + "怎么复原\n"
            + "方案一（随时可逆，推荐）\n"
            + "· 在 Q芯专区把「极致帧率」切回「原始帧率」\n"
            + "· 或者在本 App 关掉总开关 / 取消勾选\n"
            + "· 然后强制停止游戏魔盒\n"
            + "· 未勾选的应用零干预，不影响系统原生行为\n\n"
            + "方案二（彻底回到原生）\n"
            + "1. 本 App → 关于页 → 点「还原帧率表」\n"
            + "   清掉模块写进 vivo 帧率表的记录\n"
            + "2. LSPosed 里停用本模块\n"
            + "3. 重启手机\n"
            + "之后进游戏就是完全原生。\n\n"
            + "方案三（最彻底）\n"
            + "卸载本 App，LSPosed 清除模块记录，重启手机。\n\n"

            + "已知限制\n"
            + "· 超分和超帧共用同一块 MEMC，来回切换时\n"
            + "  vivo 可能提示「需要重启才能生效」\n"
            + "· 界面异常 → 强制停止游戏魔盒即可恢复\n"
            + "· 日志在下方，排查问题用，看不懂可以忽略\n";

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<PackageInfo> list;
        try {
            list = pm.getInstalledPackages(0);
        } catch (Throwable t) {
            Toast.makeText(this, "读取应用列表失败", Toast.LENGTH_LONG).show();
            return;
        }

        for (PackageInfo pi : list) {
            String pkg = pi.packageName;
            if (getPackageName().equals(pkg)) continue;
            if (pm.getLaunchIntentForPackage(pkg) == null) continue;

            String label;
            Drawable icon;
            try {
                label = pm.getApplicationLabel(pi.applicationInfo).toString();
                icon = pi.applicationInfo.loadIcon(pm);
            } catch (Throwable t) {
                label = pkg;
                icon = null;
            }
            items.add(new AppItem(pkg, label, icon));
        }

        Collections.sort(items, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem a, AppItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
    }

    private void loadPrefs() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        swMaster.setChecked(p.getBoolean("master", true));
        swGlobal.setChecked(p.getBoolean("global", false));

        checked.clear();
        String raw = p.getString("targets", "");
        appLog("loadPrefs master=" + p.getBoolean("master", true)
                + " global=" + p.getBoolean("global", false)
                + " targets=[" + raw + "] items=" + items.size());
        if (raw != null) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (s.length() > 0) checked.add(s);
            }
        }
    }

    /** 写入配置；失败不再静默，写 app.log 便于排查 */
    private void save() {
        StringBuilder sb = new StringBuilder();
        for (AppItem it : items) {
            if (checked.contains(it.pkg)) sb.append(it.pkg).append(",");
        }
        String targetsStr = sb.toString();
        boolean ok = false;
        String err = "";
        try {
            ok = getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("master", swMaster.isChecked())
                    .putBoolean("global", swGlobal.isChecked())
                    .putString("targets", targetsStr)
                    .commit();
        } catch (Throwable t) {
            err = String.valueOf(t);
        }
        String rb;
        try {
            rb = getSharedPreferences(PREFS, MODE_PRIVATE).getString("targets", "<none>");
        } catch (Throwable t) {
            rb = "<err " + t + ">";
        }
        appLog("save ok=" + ok + " master=" + swMaster.isChecked()
                + " global=" + swGlobal.isChecked()
                + " targets=[" + targetsStr + "]"
                + (err.length() > 0 ? (" err=" + err) : ""));
        appLog("readback=[" + rb + "] " + envInfo());

        // 双保险：写一份纯文本配置到公共目录，模块优先读它
        StringBuilder cfg = new StringBuilder();
        cfg.append("master=").append(swMaster.isChecked() ? "1" : "0").append('\n');
        cfg.append("global=").append(swGlobal.isChecked() ? "1" : "0").append('\n');
        cfg.append("targets=").append(targetsStr).append('\n');
        boolean cfgOk = writeText("/storage/emulated/0/GCU/user_config.txt", cfg.toString());
        appLog("writeTextConfig ok=" + cfgOk);
        updateStatus();
    }

    /** 自检：包名 / 数据目录 / shared_prefs 是否真的存在 */
    private String envInfo() {
        StringBuilder b = new StringBuilder();
        try {
            b.append("pkg=").append(getPackageName());
        } catch (Throwable ignored) { }
        try {
            File fd = getFilesDir();
            b.append(" filesDir=").append(fd == null ? "null" : fd.getAbsolutePath());
            File parent = fd == null ? null : fd.getParentFile();
            File sp = parent == null ? null : new File(parent, "shared_prefs");
            b.append(" spDir=").append(sp == null ? "null" : sp.getAbsolutePath())
                    .append(" spExists=").append(sp != null && sp.exists());
            File cfg = sp == null ? null : new File(sp, PREFS + ".xml");
            b.append(" cfgExists=").append(cfg != null && cfg.exists())
                    .append(" cfgLen=").append(cfg == null ? -1 : cfg.length());
            // 父目录一览
            if (parent != null) {
                String[] names = parent.list();
                b.append(" parentEntries=");
                if (names == null) {
                    b.append("null");
                } else {
                    for (int i = 0; i < names.length && i < 12; i++) {
                        b.append(names[i]).append(',');
                    }
                }
            }
            // 试写测试
            File probe = new File(fd, "probe.txt");
            boolean wrote = false;
            try {
                wrote = probe.createNewFile() || probe.exists();
            } catch (Throwable t2) {
                b.append(" probeErr=").append(t2.getClass().getSimpleName());
            }
            b.append(" canWriteFilesDir=").append(wrote);
        } catch (Throwable t) {
            b.append(" envErr=").append(t);
        }
        return b.toString();
    }

    /**
     * App 自身日志。
     * 优先写私有目录（不需要任何权限，一定能成），再试公共目录（便于用户导出）。
     */
    private void appLog(String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " " + msg + "\n";
        writeLine(new File(getFilesDir(), "app.log").getAbsolutePath(), line);
        writeLine("/storage/emulated/0/GCU/app.log", line);
    }

    private void writeLine(String path, String line) {
        FileOutputStream fos = null;
        try {
            File f = new File(path);
            File d = f.getParentFile();
            if (d != null && !d.exists()) d.mkdirs();
            fos = new FileOutputStream(f, true);
            fos.write(line.getBytes("UTF-8"));
            fos.flush();
        } catch (Throwable ignored) {
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) { }
        }
    }

    private void updateStatus() {
        if (swGlobal == null) return;
        if (swGlobal == null) return;
        if (swGlobal.isChecked()) {
            status.setText("全局模式：所有应用都生效");
        } else if (checked.isEmpty()) {
            status.setText("");          // 未选任何游戏：不显示误导文案
        } else {
            status.setText("已选择 " + checked.size() + " 个游戏");
        }
    }

    private class AppAdapter extends BaseAdapter {

        @Override
        public int getCount() { return items.size(); }

        @Override
        public Object getItem(int position) { return items.get(position); }

        @Override
        public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(9), dp(10), dp(9));
                row.setBackground(roundBg(C_CARD, 12));

                ImageView iv = new ImageView(MainActivity.this);
                iv.setLayoutParams(new LinearLayout.LayoutParams(iconSize, iconSize));
                row.addView(iv);

                LinearLayout texts = new LinearLayout(MainActivity.this);
                texts.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                tl.leftMargin = pad / 2;
                texts.setLayoutParams(tl);

                TextView t1 = new TextView(MainActivity.this);
                t1.setTextSize(15);
                texts.addView(t1);

                TextView t2 = new TextView(MainActivity.this);
                t2.setTextSize(10);
                t2.setAlpha(0.55f);
                texts.addView(t2);

                row.addView(texts);

                Switch sw = new Switch(MainActivity.this);
                row.addView(sw);

                h = new Holder();
                h.icon = iv;
                h.name = t1;
                h.pkg = t2;
                h.sw = sw;
                row.setTag(h);
                convertView = row;
            } else {
                h = (Holder) convertView.getTag();
            }

            final AppItem it = items.get(position);

            h.icon.setImageDrawable(it.icon);
            h.name.setText(it.label);
            h.pkg.setText(it.pkg);

            h.sw.setOnCheckedChangeListener(null);
            h.sw.setChecked(checked.contains(it.pkg));
            h.sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean v) {
                    if (v) checked.add(it.pkg); else checked.remove(it.pkg);
                    if (ready) save(); else updateStatus();
                }
            });

            final Switch fsw = h.sw;
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fsw.setChecked(!fsw.isChecked());
                }
            });

            return convertView;
        }
    }

    static class Holder {
        ImageView icon;
        TextView name;
        TextView pkg;
        Switch sw;
    }
}
