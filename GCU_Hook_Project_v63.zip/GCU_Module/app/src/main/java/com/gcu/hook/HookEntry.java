package com.gcu.hook;

import android.content.Context;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * vivo 游戏魔盒 · Q1 专区 · 超分 / 超帧 解锁  v60
 *
 * ==================================================================
 * 零、v60：把三条档位一次性交给硬件
 * ==================================================================
 * l0.b 里有两条完全不同的下发分支：
 *
 *   数组长度 == 1 → 拼字符串 "open:index:pid:depress:target"
 *   数组长度  > 1 → 拼 JSON
 *      {"open":1,"pid":x,"gameIndex":3,"frames":[
 *        {"depressFrame":30,"targetFrame":60,"gameFrame":30},
 *        {"depressFrame":60,"targetFrame":120,"gameFrame":60},
 *        {"depressFrame":72,"targetFrame":144,"gameFrame":90}]}
 *
 * 每组是「游戏跑 gameFrame 时，压到 depressFrame，补到 targetFrame」。
 *
 * 也就是说：压制值由每条规则自带，生效时机由 gameFrame 决定。
 * 两个机制本来就是分开的，只是 vivo 自己的配置永远是单条，
 * 所以这条 JSON 分支从来没被走过。
 *
 * v60 把 qb.j.c 的返回值改成 9 个元素（3 组），下游 qb.h.m 会
 * 按 下标%3 拆成三个数组交给 l0.b，于是自动走 JSON 分支。
 *
 * 好处：一次下发就覆盖 30/60/90 三种设定，游戏切场景时硬件
 * 自己换档，不需要我们重新下发。
 *
 * ==================================================================
 * 一、原生帧率直接问系统要，不再自己测
 * ==================================================================
 * 上一版想去读 SurfaceFlinger 算帧率，但那需要给「游戏魔盒」授 root，
 * 而游戏魔盒和 66 个 vivo 系统应用共享 UID 1000，授 root 等于把它们
 * 全开了。代价太大，不值。
 *
 * v59 改用 vivo 自己的 gamewatch 广播：
 *   h.Q0(pkg, fps)  ← 游戏帧率变化时系统主动播送
 *
 * 实测能拿到 30 / 60 / 90 三种值，而且它报的是「游戏设定的目标帧率」，
 * 不是测量值——所以完全不受我们压帧的影响，也不受大厅降帧影响。
 *
 * 一行日志就能看出它有多准：
 *   [gamewatch] 游戏自报帧率 = 90
 *
 * ==================================================================
 * 二、因为有了这个信号，可以删掉一大堆东西
 * ==================================================================
 * 删了：主动采样（dumpsys SurfaceFlinger）、root 依赖、
 *       历史峰值、两分钟衰减、只升不降、限制值贴边上探、
 *       中位数滑窗、跨进程文件同步、备用采样驱动。
 *
 * 因为那些全是为了「猜原生帧率」而写的补偿，现在直接问就行。
 *
 * ==================================================================
 * 三、档位表
 * ==================================================================
 *   上报 30 / 限制 30 / 目标  60
 *   上报 60 / 限制 60 / 目标 120
 *   上报 72 / 限制 72 / 目标 144
 *
 * 选档：向上取整（取不小于原生帧率的最小档位）
 *   原生 30 → 30 档（不压）
 *   原生 60 → 60 档（不压）
 *   原生 90 → 72 档（唯一真压，因为 90×2=180 超屏）
 *   原生 >92 → 不接入
 *
 * MEMC 只能 2 倍，所以 target = 2 × depress，且 target 不能超过屏幕峰值。
 *
 * ==================================================================
 * 四、没收到信号的时候用 60 档
 * ==================================================================
 * 默认 60 档：不压任何跑 30 或 60 的游戏，又能给 60 的游戏补到 120。
 * 收到 gamewatch 后立即改成对应的档。
 *
 * ==================================================================
 * 五、hook 清单
 * ==================================================================
 *   超分 7 处   a.Y0 / a.H1 / e0.a1 / e0.p0 / e0.o0 / qr.f / se.j.d
 *   超帧 5 个   qb.j.t / i.c / i.o / h.Q0 / h.l0
 *   诊断 5 组   FpsManager.h / l0.b / algorithem.b.f / o0+I0 / j0
 */
public class HookEntry implements IXposedHookLoadPackage {

    // ==================================================================
    // 常量
    // ==================================================================

    private static final String TAG    = "GCU";
    private static final String TARGET = "com.vivo.gamecube";
    private static final String SELF   = "com.gcu.hook";

    private static final String CFG_FILE   = "/storage/emulated/0/GCU/user_config.txt";
    private static final String STATE_FILE = "/storage/emulated/0/GCU/fps.json";
    private static final String LOG_PUBLIC = "/storage/emulated/0/GCU/gcu.log";
    private static final String LOG_PRIVATE =
            "/data/data/com.vivo.gamecube/files/gcu_debug.log";
    private static final long LOG_LIMIT = 512 * 1024L;

    private static final String PROVIDER = "qb.j";
    private static final String ENTITY   = "com.vivo.common.frameintersupportlist.entity.a";
    private static final String TIER     = "o9.b";
    private static final String FI_I     = "com.vivo.gameassistant.frameinterpolation.i";
    private static final String FI_H     = "com.vivo.gameassistant.frameinterpolation.h";
    private static final String FPS_MGR  = "com.vivo.gameassistant.framedisplay.FpsManager";
    private static final String ALGO_B   = "com.vivo.common.algorithem.b";
    private static final String UTIL_L0  = "com.vivo.common.utils.l0";

    private static final String CFG_CLASS = "com.vivo.common.a";
    private static final String UTILS     = "com.vivo.gameassistant.utils.e0";
    private static final String VSR_Q     = "com.vivo.gameassistant.superresolution.q";
    private static final String LIVE      = "se.j";

    private static final int GAME_INDEX = 3;

    /**
     * {游戏声明帧率, 限制值, 目标值}
     *
     * 第一列必须是「游戏自己声明的值」。多行下发时，硬件靠这一列
     * 来挑行；同时 i.c 也把它报给 vivo 去查档位表，两边是同一个数。
     *
     * 第三行写 90 而不是 72：游戏声明 90，我们把它压到 72，
     * 再补到 144。如果这里写 72，硬件就以为游戏只会跑 72，
     * 战斗场景声明 90 时匹配不上任何一行，插帧直接不工作。
     */
    private static final int[][] TIERS = {
            {30, 30, 60},
            {60, 60, 120},
            {90, 72, 144},
    };

    /** 没收到 gamewatch 信号时默认用哪一档（1 = 60 档） */
    private static final int DEFAULT_TIER = 1;

    /** 原生帧率超过这个值就不接入（原生 120 档） */
    private static final int MAX_NATIVE_FPS = 92;

    private static final long FPS_LOG_GAP = 10000L;

    /**
     * 档位表模式。
     *
     * true  = 单条（默认）。vivo 的下游消费者只认 open:index:pid:depress:target
     *         这种简单格式，实测已经确认。
     * false = 三条 JSON。接口本身支持（l0.b 里有这个分支），但下发后
     *         系统解析不了，整条命令被丢弃，插帧直接不工作。留作以后试验。
     *
     * 想再试 JSON，在 /storage/emulated/0/GCU/ 下建 multi_tier.flag
     */
    private static final String MULTI_TIER_FLAG =
            "/storage/emulated/0/GCU/multi_tier.flag";

    private static volatile boolean singleMode = true;

    /** 帧率采样器（照抄 FpsManager.d 的做法，不需要 root） */
    private static volatile String  layerName     = null;
    private static volatile String  layerPkg      = null;
    private static volatile boolean samplerStarted = false;
    private static volatile boolean shellFailLogged = false;

    private static final String DUMP = "dumpsys SurfaceFlinger";

    /** ladderValue 的哨兵值 */
    private static final int LV_UNKNOWN = -1;
    private static final int LV_SKIP    = 0;

    // ==================================================================
    // 配置与状态
    // ==================================================================

    private boolean master = true;
    private boolean global = false;
    private final HashSet<String> targets = new HashSet<>();

    private static volatile String currentGame = null;

    /** 重发需要的现场：最后一次成功下发时的 gameIndex / pid / 开关态 */
    private static volatile int     lastGameIndex = -1;
    private static volatile int     lastPid       = -1;
    private static volatile boolean lastOpen      = false;
    private static volatile ClassLoader sCL       = null;
    private static final Map<String, Object> entityCache = new HashMap<>();
    private static final HashSet<String> loggedMiss = new HashSet<>();

    /**
     * 当前下发值。
     *   LV_UNKNOWN (-1) 还没收到 gamewatch 信号
     *   LV_SKIP    (0)  原生太快，不接入
     *   30 / 60 / 72    具体档位
     */
    private static volatile int ladderValue = LV_UNKNOWN;

    /** 最近一次 gamewatch 报的值，用于去重 */
    private static volatile int    gamewatchFps = -1;
    private static volatile String gamewatchPkg = null;

    /** 诊断用的被动帧率（只打日志，不参与决策） */
    private static volatile long lastFpsLog = 0L;
    private static volatile String lastMemcKey = null;
    private static volatile Object lastMemcVal = null;
    private static volatile int  lastReported = Integer.MIN_VALUE;

    // ==================================================================
    // 入口
    // ==================================================================

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!TARGET.equals(lp.packageName)) return;

        loadConfig();
        plog(": 注入 " + lp.processName + " master=" + master
                + " global=" + global + " targets=" + targets);

        if (!master) {
            plog(": 总开关关闭，零干预");
            return;
        }
        if (!global && targets.isEmpty()) {
            plog(": 未勾选任何应用，零干预");
            return;
        }

        ClassLoader cl = lp.classLoader;
        sCL = cl;

        installSrCapability(cl);
        installSrWhitelist(cl);

        installEntity(cl);
        installTierTable(cl);
        installFpsReport(cl);
        installFpsRecord(cl);
        installFpsBroadcast(cl);
        installCloseGuard(cl);
        installFpsDiagnostic(cl);
        installPipelineTrace(cl);
        installJ0Trace(cl);

        startFpsSampler();

        plog(": 全部挂载完成（超分 7 / 超帧 5 / 档位表 / 诊断 5）");
        plog(": 档位表模式=" + (singleMode ? "单条（默认）" : "三条 JSON（实验）") + " / 切档重发=" + true);
    }

    // ==================================================================
    // 配置
    // ==================================================================

    private void loadConfig() {
        singleMode = !new java.io.File(MULTI_TIER_FLAG).exists();
        if (loadConfigFromFile()) return;
        try {
            XSharedPreferences p = new XSharedPreferences(SELF, "config");
            p.reload();
            master = p.getBoolean("master", true);
            global = p.getBoolean("global", false);
            parseTargets(p.getString("targets", ""));
            plog(": 配置来源=SharedPreferences targets=" + targets);
        } catch (Throwable t) {
            plog(": 读配置失败 " + t);
        }
    }

    private boolean loadConfigFromFile() {
        java.io.BufferedReader br = null;
        try {
            java.io.File f = new java.io.File(CFG_FILE);
            if (!f.exists()) return false;
            br = new java.io.BufferedReader(new java.io.InputStreamReader(
                    new java.io.FileInputStream(f), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("master=")) {
                    master = "1".equals(line.substring(7).trim());
                } else if (line.startsWith("global=")) {
                    global = "1".equals(line.substring(7).trim());
                } else if (line.startsWith("targets=")) {
                    parseTargets(line.substring(8));
                }
            }
            plog(": 配置来源=文件 targets=" + targets);
            return true;
        } catch (Throwable t) {
            plog(": 读文件配置失败 " + t);
            return false;
        } finally {
            try { if (br != null) br.close(); } catch (Throwable ignored) { }
        }
    }

    private void parseTargets(String raw) {
        targets.clear();
        if (raw == null) return;
        for (String s : raw.split(",")) {
            s = s.trim();
            if (s.length() > 0) targets.add(s);
        }
    }

    // ==================================================================
    // 作用域
    // ==================================================================

    private boolean allow(Object pkgObj) {
        String p;
        if (pkgObj instanceof String && ((String) pkgObj).length() > 0) {
            p = (String) pkgObj;
        } else {
            p = currentGame;
        }
        if (p == null || p.length() == 0) return false;

        if (global) {
            currentGame = p;
            return true;
        }
        if (!targets.contains(p)) {
            logMissOnce(p);
            return false;
        }
        currentGame = p;
        return true;
    }

    private void logMissOnce(String p) {
        synchronized (loggedMiss) {
            if (loggedMiss.contains(p)) return;
            loggedMiss.add(p);
        }
        plog(": [scope] 未勾选 pkg=" + p);
    }

    // ==================================================================
    // A. 超分
    // ==================================================================

    private void forceBool(String cls, String name, int argCount, final int pkgIdx,
                           ClassLoader cl, final boolean ret) {
        try {
            Class<?> c = XposedHelpers.findClass(cls, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name)) continue;
                if (m.getReturnType() != boolean.class) continue;
                if (argCount >= 0 && m.getParameterTypes().length != argCount) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (pkgIdx < 0) {
                            param.setResult(ret);
                            return;
                        }
                        if (pkgIdx >= param.args.length) return;
                        if (allow(param.args[pkgIdx])) param.setResult(ret);
                    }
                });
                n++;
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + cls + "." + name);
        } catch (Throwable t) {
            plog(": FAIL " + cls + "." + name + " -> " + t);
        }
    }

    private void installSrCapability(ClassLoader cl) {
        forceBool(CFG_CLASS, "Y0", 0, -1, cl, true);
        forceBool(CFG_CLASS, "H1", 0, -1, cl, true);
    }

    private void installSrWhitelist(ClassLoader cl) {
        forceBool(UTILS, "a1", 2, 1, cl, true);
        forceBool(UTILS, "p0", 1, 0, cl, true);
        forceBool(UTILS, "o0", 1, 0, cl, true);
        forceBool(VSR_Q, "f", 1, 0, cl, true);
        forceBool(LIVE, "d", 1, 0, cl, false);
    }

    // ==================================================================
    // B. 造实体
    // ==================================================================

    private void installEntity(final ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(PROVIDER, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals("t")) continue;
                if (m.getParameterTypes().length != 1) continue;
                if (!String.class.equals(m.getParameterTypes()[0])) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            Object raw = param.args[0];
                            String pkg = (raw instanceof String && ((String) raw).length() > 0)
                                    ? (String) raw : currentGame;
                            if (pkg == null || pkg.length() == 0) return;
                            if (!allow(pkg)) return;
                            // 原生太快：不给选项，卡片不出现
                            if (ladderValue == LV_SKIP) return;
                            Object e = entityFor(pkg, cl);
                            if (e != null) param.setResult(e);
                        } catch (Throwable ignored) { }
                    }
                });
                n++;
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + PROVIDER + ".t（造实体）");
        } catch (Throwable t) {
            plog(": FAIL " + PROVIDER + ".t -> " + t);
        }
    }

    private Object entityFor(String pkg, ClassLoader cl) {
        synchronized (entityCache) {
            Object cached = entityCache.get(pkg);
            if (cached != null) return cached;
        }
        try {
            Class<?> entCls  = XposedHelpers.findClass(ENTITY, cl);
            Class<?> tierCls = XposedHelpers.findClass(TIER, cl);

            List<Object> boost = new ArrayList<>();
            for (int[] t : TIERS) {
                boost.add(XposedHelpers.newInstance(tierCls, new Object[]{ t[0], t[1], t[2] }));
            }

            Object ent = XposedHelpers.newInstance(entCls, new Object[]{
                    pkg, pkg, "vivo",
                    GAME_INDEX,
                    Boolean.TRUE,
                    boost,
                    new ArrayList<>(),
                    new HashMap<Integer, Map<String, String>>(),
                    0.0d, 0.0d,
                    0,
                    0, ""
            });

            synchronized (entityCache) {
                entityCache.put(pkg, ent);
            }
            plog(": [entity] " + pkg + " 自建实体 index=" + GAME_INDEX
                    + " 档位=" + TIERS.length + " 条 monsterPlus=0");
            return ent;
        } catch (Throwable t) {
            plog(": [entity] 构造失败 " + t);
            return null;
        }
    }

    // ==================================================================
    // B2. 档位表：把三条一股脑交给硬件
    // ==================================================================

    /**
     * qb.j.c 负责产出下发给硬件的帧率映射。默认只给一条（3 个数）。
     *
     * 这里把它换成整张表（3 组 = 9 个数），下游 qb.h.m 会按
     * 下标 % 3 拆成三个同长数组交给 l0.b，l0.b 看到长度 > 1
     * 就自动改拼 JSON，一次把三种帧率档位全交给硬件。
     *
     * 不直接改实体的 supportSDK，是为了避开那个布尔量在其他
     * 地方（qb.j.d / oa.b）可能带来的副作用。
     */
    private void installTierTable(final ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(PROVIDER, cl, "c",
                    Context.class, int.class, int.class, int.class,
                    "com.vivo.gameassistant.frameinterpolation.FrameInterpolationState",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (singleMode) return;   // 回退：保持单条
                                if (!allow(null)) {
                                    logTierTableSkip();
                                    return;
                                }
                                param.setResult(buildFlatTable());
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   qb.j.c（档位表 → " + TIERS.length + " 组）");
        } catch (Throwable t) {
            plog(": FAIL qb.j.c -> " + t);
        }
    }

    /** 拼成 [depress, target, gameFrame] × N；这个顺序必须和 qb.h.m 的拆包一致 */
    private static int[] buildFlatTable() {
        int[] flat = new int[TIERS.length * 3];
        for (int i = 0; i < TIERS.length; i++) {
            flat[i * 3]     = TIERS[i][1];   // depressFrame
            flat[i * 3 + 1] = TIERS[i][2];   // targetFrame
            flat[i * 3 + 2] = TIERS[i][0];   // gameFrame
        }
        return flat;
    }

    private static volatile boolean tierTableSkipLogged = false;

    private static void logTierTableSkip() {
        if (tierTableSkipLogged) return;
        tierTableSkipLogged = true;
        plog(": [tier] qb.j.c 未接管（currentGame 为空或未勾选）");
    }

    // ==================================================================
    // C. 帧率口径
    // ==================================================================

    private void installFpsReport(final ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(FI_I, cl, "c",
                    Context.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (!allow(param.args[1] instanceof String ? param.args[1] : null)) return;
                                int want = currentTier();
                                if (want <= 0) return;
                                int orig = (param.getResult() instanceof Integer)
                                        ? (Integer) param.getResult() : Integer.MIN_VALUE;
                                if (orig == want) return;
                                param.setResult(want);
                                if (orig != lastReported) {
                                    lastReported = orig;
                                    plog(": [report] 表里=" + orig + " → 上报 " + want);
                                }
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   frameinterpolation.i.c（上报）");
        } catch (Throwable t) {
            plog(": FAIL i.c -> " + t);
        }
    }

    private void installFpsRecord(final ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(FI_I, cl, "o",
                    Context.class, String.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (!allow(param.args[1] instanceof String ? param.args[1] : null)) return;
                                int want = currentTier();
                                if (want > 0) param.args[2] = want;
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   frameinterpolation.i.o（写入）");
        } catch (Throwable t) {
            plog(": FAIL i.o -> " + t);
        }
    }

    /**
     * h.Q0(pkg, fps)：gamewatch 广播游戏的目标帧率。
     *
     * 这里是整个模块的脑子：
     *   1. 先拿原始值定档（它是系统直接告诉我们的原生帧率）
     *   2. 再把参数改成我们的档位值，避免 vivo 拿两个不同的数去比对
     *      然后调 l0 把插帧关掉
     */
    private void installFpsBroadcast(final ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(FI_H, cl, "Q0",
                    String.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                if (!allow(param.args[0] instanceof String ? param.args[0] : null)) return;

                                Object raw = param.args[1];
                                if (raw instanceof Integer) {
                                    noteGamewatch((Integer) raw);
                                }

                                int want = currentTier();
                                if (want > 0) param.args[1] = want;
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   frameinterpolation.h.Q0（gamewatch）");
        } catch (Throwable t) {
            plog(": FAIL Q0 -> " + t);
        }
    }

    /**
     * gamewatch 报来一个原生帧率，立即定档。
     * 这是设定值，不是测量值，所以不需要平滑也不需要防大厅。
     */
    private static void noteGamewatch(int fps) {
        if (fps <= 0) return;

        String g = currentGame;
        if (g != null) {
            if (gamewatchPkg != null && !g.equals(gamewatchPkg)) {
                plog(": [ladder] 换游戏 " + gamewatchPkg + " → " + g + "，档位重置");
                ladderValue = LV_UNKNOWN;
                gamewatchFps = -1;
            }
            gamewatchPkg = g;
        }

        if (fps == gamewatchFps) return;
        int oldValue = ladderValue;
        gamewatchFps = fps;

        // 原生太快：不接入
        if (fps > MAX_NATIVE_FPS) {
            if (ladderValue != LV_SKIP) {
                ladderValue = LV_SKIP;
                plog(": [ladder] 原生 " + fps + " 超过 " + MAX_NATIVE_FPS
                        + "，不接入插帧（卡片不出现）");
            }
            saveState(fps);
            return;
        }

        // 向上取整：不小于 fps 的最小档位
        int want = TIERS.length - 1;
        for (int i = 0; i < TIERS.length; i++) {
            if (fps <= TIERS[i][0]) { want = i; break; }
        }
        int newValue = TIERS[want][0];

        if (newValue == oldValue) {
            plog(": [ladder] 原生 " + fps + " → 保持 " + newValue
                    + " 档（限制 " + TIERS[want][1] + " 目标 " + TIERS[want][2] + "）");
            saveState(fps);
            return;
        }

        ladderValue = newValue;
        if (oldValue == LV_UNKNOWN) {
            plog(": [ladder] 原生 " + fps + " → 初始 " + newValue
                    + " 档（限制 " + TIERS[want][1] + " 目标 " + TIERS[want][2] + "）");
        } else {
            plog(": [ladder] 原生 " + fps + " → 切到 " + newValue
                    + " 档（限制 " + TIERS[want][1] + " 目标 " + TIERS[want][2] + "）");
        }
        reissueAsync();
        saveState(fps);
    }

    /**
     * 档位变了，但 vivo 不会自己重新下发。
     *
     * 这里直接调 i.h(gameIndex, pid, depress[], target[], gameFrame[])，
     * 它内部就是 l0.b，会把新档位写回系统设置。
     * 只在当前处于开启状态时重发，避免把已经关掉的插帧又打开。
     */
    private static void reissueAsync() {
        if (!lastOpen) return;
        final int gidx  = lastGameIndex;
        final int pid   = lastPid;
        final int value = currentTier();
        if (gidx < 0 || pid <= 0 || value <= 0) return;

        int depress = -1, target = -1, gameFrame = -1;
        for (int[] t : TIERS) {
            if (t[0] == value) { gameFrame = t[0]; depress = t[1]; target = t[2]; break; }
        }
        if (depress <= 0) return;

        final int d  = depress;
        final int tg = target;
        final int gf = gameFrame;
        final ClassLoader cl = sCL;

        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try { Thread.sleep(400L); } catch (Throwable e) { return; }
                try {
                    Class<?> ic = XposedHelpers.findClass(
                            "com.vivo.gameassistant.frameinterpolation.i", cl);
                    Object inst = XposedHelpers.callStaticMethod(ic, "e");
                    XposedHelpers.callMethod(inst, "h", gidx, pid,
                            new int[]{ d }, new int[]{ tg }, new int[]{ gf });
                    plog(": [reissue] 重发 depress=" + d + " target=" + tg
                            + " gameFrame=" + gf);
                } catch (Throwable e) {
                    plog(": [reissue] 失败 " + e);
                }
            }
        }, "gcu-reissue");
        th.setDaemon(true);
        th.start();
    }

    // ==================================================================
    // D. 关闭拦截
    // ==================================================================

    private void installCloseGuard(final ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(FI_H, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals("l0")) continue;
                if (m.getParameterTypes().length != 1) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        try {
                            if (!allow(null)) return;
                            if (String.valueOf(param.args[0]).contains("GAME_FPS_CHANGE")) {
                                param.setResult(null);
                                plog(": [guard] 拦截 GAME_FPS_CHANGE，保持开启");
                            }
                        } catch (Throwable ignored) { }
                    }
                });
                n++;
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + "frameinterpolation.h.l0（关闭拦截）");
        } catch (Throwable t) {
            plog(": FAIL l0 -> " + t);
        }
    }

    // ==================================================================
    // E. 当前下发值
    // ==================================================================

    /** 返回要下发的帧率值；0 表示不干预（原生太快） */
    private static int currentTier() {
        int v = ladderValue;
        if (v == LV_SKIP) return 0;
        if (v > 0) return v;
        return TIERS[DEFAULT_TIER][0];   // 还没收到信号，用默认 60 档
    }

    // ==================================================================
    // F0. 帧率采样器：自己跑 dumpsys，不需要 root
    // ==================================================================
    //
    // 魔盒跑在 UID 1000（系统），天生就有 DUMP 权限，所以普通的
    // Runtime.exec 就能读 SurfaceFlinger，不用 su。v58 那次套了
    // su 反而要 root 才能跑，是弄错了。
    //
    // 算法完全照抄 FpsManager.d(String)：
    //   dumpsys SurfaceFlinger --latency "<层>"
    //   → 去掉首行 "--"
    //   → 不足 30 行就放弃
    //   → 从后往前清洗：必须正好 3 段，且第 1 段与第 2 段等长
    //   → 数最近 800ms 内的帧数
    //   → fps = 帧数 × 1.25

    private void startFpsSampler() {
        if (samplerStarted) return;
        samplerStarted = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                plog(": [sampler] 启动（直接调 dumpsys，不需要 root）");
                while (true) {
                    try {
                        Thread.sleep(1000L);
                    } catch (Throwable e) {
                        return;
                    }
                    try {
                        String pkg = currentGame;
                        if (pkg == null || pkg.length() == 0) continue;

                        String layer = findLayer(pkg);
                        if (layer == null) continue;

                        float f = vivoFps(layer);
                        if (f <= 0f) continue;
                        plog(": [fps] 实测=" + f + " 层=" + layer);
                    } catch (Throwable ignored) { }
                }
            }
        }, "gcu-fps");
        t.setDaemon(true);
        t.start();
    }

    /** 找出当前应用的渲染层 */
    private static String findLayer(String pkg) {
        String cached = layerName;
        if (cached != null && pkg.equals(layerPkg)) return cached;

        String out = shell(DUMP + " --list");
        if (out == null || out.length() == 0) {
            logShellFail();
            return null;
        }

        String best = null;
        for (String line : out.split("\\n")) {
            line = line.trim();
            if (line.length() == 0) continue;
            if (!line.contains(pkg)) continue;
            if (line.contains("SurfaceView")) { best = line; break; }
            if (best == null) best = line;
        }
        if (best == null) {
            logShellFail();
            return null;
        }

        layerPkg = pkg;
        layerName = best;
        plog(": [sampler] 渲染层 = " + best);
        return best;
    }

    private static void logShellFail() {
        if (shellFailLogged) return;
        shellFailLogged = true;
        plog(": [sampler] 读不到渲染层——dumpsys 被拒或应用不在前台");
    }

    /** 照抄 FpsManager.d 的算法 */
    private static float vivoFps(String layer) {
        String out = shell(DUMP + " --latency \"" + layer + "\"");
        if (out == null || out.length() == 0) return -1f;

        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        for (String s : out.split("\\n")) {
            s = s.trim();
            if (s.length() > 0) lines.add(s);
        }
        if (lines.isEmpty()) return -1f;
        if (lines.get(0).startsWith("--")) lines.remove(0);
        if (lines.size() < 30) return -1f;

        for (int i = lines.size() - 1; i >= 0; i--) {
            String[] p = lines.get(i).split("\\t");
            if (p.length != 3 || p[0].length() != p[1].length()) lines.remove(i);
        }
        if (lines.isEmpty()) return -1f;

        long latest;
        try {
            latest = Long.parseLong(lines.get(lines.size() - 1).split("\\t")[1]);
        } catch (Throwable t) {
            return -1f;
        }
        if (latest <= 0L) return -1f;

        long from = latest - 800000000L;   // 800ms 窗口
        int count = 0;
        for (int i = lines.size() - 1; i >= 0; i--) {
            long v;
            try {
                v = Long.parseLong(lines.get(i).split("\\t")[1]);
            } catch (Throwable t) {
                continue;
            }
            if (v > latest || v < from) break;
            count++;
        }
        return count * 1.25f;
    }

    /** 跑一条 shell，不需要 root */
    private static String shell(String cmd) {
        StringBuilder sb = new StringBuilder();
        Process p = null;
        java.io.BufferedReader br = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{ "/system/bin/sh", "-c", cmd });
            try { p.getOutputStream().close(); } catch (Throwable ignored) { }
            br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(p.getInputStream(), "UTF-8"));
            String line;
            long t0 = System.currentTimeMillis();
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
                if (sb.length() > 65536) break;
                if (System.currentTimeMillis() - t0 > 3000L) break;
            }
            p.waitFor();
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (br != null) br.close(); } catch (Throwable ignored) { }
            try { if (p != null) p.destroy(); } catch (Throwable ignored) { }
        }
        return sb.toString();
    }

    // ==================================================================
    // F. 被动帧率诊断（只打日志，不参与决策）
    // ==================================================================    // ==================================================================
    // F. 被动帧率诊断（只打日志，不参与决策）
    // ==================================================================

    private void installFpsDiagnostic(final ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(FPS_MGR, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals("h")) continue;
                if (m.getReturnType() != float.class) continue;
                if (m.getParameterTypes().length != 1) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            Object r = param.getResult();
                            if (!(r instanceof Float)) return;
                            long now = System.currentTimeMillis();
                            if (now - lastFpsLog < FPS_LOG_GAP) return;
                            lastFpsLog = now;
                            plog(": [fps] 被动=" + r + " | gamewatch=" + gamewatchFps
                                    + " | 下发=" + currentTier());
                        } catch (Throwable ignored) { }
                    }
                });
                n++;
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + "FpsManager.h（被动诊断）");
        } catch (Throwable t) {
            plog(": FAIL FpsManager.h -> " + t);
        }
    }

    // ==================================================================
    // G. 状态文件（方便排查）
    // ==================================================================

    private static void saveState(int gamewatchValue) {
        java.io.FileOutputStream fos = null;
        try {
            java.io.File f = new java.io.File(STATE_FILE);
            java.io.File d = f.getParentFile();
            if (d != null && !d.exists()) d.mkdirs();
            String pkg = gamewatchPkg == null ? "" : gamewatchPkg;
            String json = "{\"ts\":" + System.currentTimeMillis()
                    + ",\"pkg\":\"" + pkg + "\""
                    + ",\"gamewatch\":" + gamewatchValue
                    + ",\"tier\":" + currentTier()
                    + "}";
            fos = new java.io.FileOutputStream(f, false);
            fos.write(json.getBytes("UTF-8"));
            fos.flush();
        } catch (Throwable ignored) {
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) { }
        }
    }

    // ==================================================================
    // H. 诊断
    // ==================================================================

    private void installPipelineTrace(final ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(UTIL_L0, cl, "b",
                    Context.class, boolean.class, int.class, int.class,
                    int[].class, int[].class, int[].class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                lastOpen = Boolean.TRUE.equals(param.args[1]);
                                if (lastOpen) {
                                    lastGameIndex = (Integer) param.args[2];
                                    lastPid = (Integer) param.args[3];
                                }
                                int[] d = (int[]) param.args[4];
                                int[] tg = (int[]) param.args[5];
                                int[] gf = (int[]) param.args[6];
                                String fmt = (tg != null && tg.length > 1) ? "JSON" : "单条";
                                plog(": [write] open=" + param.args[1]
                                        + " index=" + param.args[2]
                                        + " pid=" + param.args[3]
                                        + " 格式=" + fmt
                                        + " depress=" + java.util.Arrays.toString(d)
                                        + " target=" + java.util.Arrays.toString(tg)
                                        + " gameFrame=" + java.util.Arrays.toString(gf));
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   l0.b（最终命令诊断）");
        } catch (Throwable t) {
            plog(": FAIL l0.b 诊断 -> " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(ALGO_B, cl, "f",
                    Context.class, String.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                String key = String.valueOf(param.args[2]);
                                Object val = param.getResult();
                                if (key.equals(lastMemcKey)
                                        && String.valueOf(val).equals(String.valueOf(lastMemcVal))) {
                                    return;
                                }
                                lastMemcKey = key;
                                lastMemcVal = val;
                                plog(": [memc] " + key + " => " + val);
                            } catch (Throwable ignored) { }
                        }
                    });
            plog(": OK   algorithem.b.f（门④诊断）");
        } catch (Throwable t) {
            plog(": FAIL 门④诊断 -> " + t);
        }

        try {
            Class<?> c = XposedHelpers.findClass(FI_H, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals("o0") && m.getParameterTypes().length == 0) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                plog(": [temp] o0() = " + param.getResult());
                            } catch (Throwable ignored) { }
                        }
                    });
                    n++;
                } else if (m.getName().equals("I0") && m.getParameterTypes().length == 1) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                plog(": [overheat] I0(" + param.args[0] + ") = " + param.getResult());
                            } catch (Throwable ignored) { }
                        }
                    });
                    n++;
                }
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + "门③诊断（温度/过热）");
        } catch (Throwable t) {
            plog(": FAIL 门③诊断 -> " + t);
        }
    }

    private void installJ0Trace(final ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass(FI_H, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals("j0")) continue;
                if (m.getParameterTypes().length != 3) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            plog(": [j0] " + param.args[0]
                                    + " reason=" + param.args[2]
                                    + " -> " + param.getResult()
                                    + "（下发=" + currentTier() + "）");
                        } catch (Throwable ignored) { }
                    }
                });
                n++;
            }
            plog((n > 0 ? ": OK   " : ": MISS ") + "frameinterpolation.h.j0（日志）");
        } catch (Throwable t) {
            plog(": FAIL j0 -> " + t);
        }
    }

    // ==================================================================
    // ==================================================================
    // 日志
    // ==================================================================    // ==================================================================
    // ==================================================================
    // 日志
    // ==================================================================

    private static void plog(String msg) {
        String line = TAG + msg;
        XposedBridge.log(line);
        String ts = new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
                .format(new java.util.Date());
        String out = ts + " " + line + "\n";
        appendTo(LOG_PRIVATE, out);
        appendTo(LOG_PUBLIC, out);
    }

    private static void appendTo(String path, String line) {
        java.io.FileOutputStream fos = null;
        try {
            java.io.File f = new java.io.File(path);
            java.io.File d = f.getParentFile();
            if (d != null && !d.exists()) d.mkdirs();
            if (f.exists() && f.length() > LOG_LIMIT) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
            fos = new java.io.FileOutputStream(f, true);
            fos.write(line.getBytes("UTF-8"));
            fos.flush();
        } catch (Throwable ignored) {
        } finally {
            try { if (fos != null) fos.close(); } catch (Throwable ignored) { }
        }
    }
}
