# 游戏魔盒解锁 (GCU Hook)

LSPosed 模块：手动勾选任意 App，让 vivo 游戏魔盒对它放行
超分辨率 / 插帧。

目标应用：`com.vivo.gamecube`（vivo 游戏魔盒 14.0.18.02）

---

## 一、编译 APK（用 GitHub 免费编译，不用装 Android Studio）

1. 注册 GitHub 账号（免费）：https://github.com/signup
2. 新建一个仓库：https://github.com/new
   - Repository name 随便填，比如 `gcu-hook`
   - 选 **Public**（私有仓库 Actions 要收费）
   - 点 Create repository
3. 在仓库页点 **uploading an existing file**
4. 把本项目文件夹里的**所有文件和文件夹**拖进去
   - 注意：`.github` 文件夹要一起传（它是隐藏文件夹，可能需要在文件管理器里开启“显示隐藏文件”）
   - 如果 `.github` 传不上去，用网页的 “Create new file”，文件名填
     `.github/workflows/build.yml`，内容从本地同路径文件复制粘贴
5. 点 **Commit changes**
6. 等 2~3 分钟，打开仓库顶部的 **Actions** 标签页
7. 点最新的那次运行 → 页面底部 **Artifacts** → 下载 `GCU-Hook-APK`
8. 解压得到 `app-debug.apk`

---

## 二、安装与启用

1. 把 `app-debug.apk` 安装到手机
   （可能提示“未知来源”，允许即可）
2. 打开 **LSPosed 管理器** → 底部 **模块** → 找到 **游戏魔盒解锁**
3. **必须做**：点进去 → 允用模块 → **作用域** → 勾选 `com.vivo.gamecube`
   - 若列表里看不到它，右上角菜单 → **显示系统应用**
4. 重启手机

---

## 三、使用

1. 打开桌面上的 **游戏魔盒解锁** App
2. 列表里勾选你要解锁的游戏
3. 点 **保存**
4. 强制停止游戏魔盒（设置 → 应用 → 游戏魔盒 → 强制停止），
   或直接重启手机
5. 开游戏，拉侧边栏看有没有「超分辨率」入口

### 开关说明

| 项 | 作用 |
|---|---|
| 总开关 | 关掉后所有 Hook 都不生效 |
| 全局模式 | 对所有 App 生效，不用逐个勾（风险高，慎用） |
| 列表勾选 | 只对勾选的包名放行 |

---

## 四、如何看日志

如果没效果，先看模块有没有正常加载：

方式 A：LSPosed 管理器 → 日志 → 筛 `GCU`

方式 B：命令行
```bash
su -c 'logcat -d | grep GCU'
```

正常应该看到：
```
GCU: 注入 com.vivo.gamecube | master=true global=false targets=1
GCU: OK   a1
GCU: OK   E0
GCU: OK   Y0
...
GCU: 全部 Hook 已挂载
```

如果出现 `FAIL`，把那一行发给我。

---

## 五、本地编译（不想用 GitHub 的话）

需要：JDK 17 + Android SDK（build-tools 34 / platform 34）+ Gradle 8.x

```bash
gradle assembleDebug
```

APK 在 `app/build/outputs/apk/debug/app-debug.apk`

---

## 六、已知限制

- 本模块只负责「让游戏魔盒不拦你」，**不保证底层真的执行超分**。
  最终效果取决于设备是否有 MEMC 硬件能力与系统侧实现。
- 目标设备已确认：PD2307 / SM8650（vivo X100 系），
  机型本身在 APK 硬编码的超分支持列表里。
- 若游戏魔盒升级到新版本，混淆名可能变化，需重新定位。
