package com.gcu.hook;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

/**
 * 配置界面：勾选需要开启超分/插帧的 App
 */
public class MainActivity extends Activity {

    private static final String PREFS = "config";

    private CheckBox cbMaster;
    private CheckBox cbGlobal;
    private ListView listView;

    private final ArrayList<String> pkgs = new ArrayList<>();
    private final ArrayList<String> labels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (16 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("游戏魔盒解锁");
        title.setTextSize(22);
        root.addView(title);

        TextView tip = new TextView(this);
        tip.setText("勾选需要开启超分辨率 / 插帧的 App。\n保存后需重启「游戏魔盒」进程生效。");
        tip.setTextSize(13);
        tip.setPadding(0, pad / 2, 0, pad);
        root.addView(tip);

        cbMaster = new CheckBox(this);
        cbMaster.setText("总开关");
        cbMaster.setChecked(true);
        root.addView(cbMaster);

        cbGlobal = new CheckBox(this);
        cbGlobal.setText("全局模式（所有 App 生效，慎用）");
        root.addView(cbGlobal);

        listView = new ListView(this);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = pad / 2;
        root.addView(listView, lp);

        Button save = new Button(this);
        save.setText("保存");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        root.addView(save);

        setContentView(root);

        loadApps();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_multiple_choice, labels);
        listView.setAdapter(adapter);
        loadPrefs();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<PackageInfo> list;
        try {
            list = pm.getInstalledPackages(0);
        } catch (Throwable t) {
            Toast.makeText(this, "读取应用列表失败: " + t, Toast.LENGTH_LONG).show();
            return;
        }

        ArrayList<String[]> rows = new ArrayList<>();
        for (PackageInfo pi : list) {
            String pkg = pi.packageName;
            if (getPackageName().equals(pkg)) continue;
            if (pm.getLaunchIntentForPackage(pkg) == null) continue;
            String label;
            try {
                label = pm.getApplicationLabel(pi.applicationInfo).toString();
            } catch (Throwable t) {
                label = pkg;
            }
            rows.add(new String[]{pkg, label});
        }

        Collections.sort(rows, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return a[1].compareToIgnoreCase(b[1]);
            }
        });

        for (String[] r : rows) {
            pkgs.add(r[0]);
            labels.add(r[1] + "\n" + r[0]);
        }
    }

    private void loadPrefs() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        cbMaster.setChecked(p.getBoolean("master", true));
        cbGlobal.setChecked(p.getBoolean("global", false));

        HashSet<String> set = new HashSet<>();
        String raw = p.getString("targets", "");
        if (raw != null) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (s.length() > 0) set.add(s);
            }
        }
        for (int i = 0; i < pkgs.size(); i++) {
            listView.setItemChecked(i, set.contains(pkgs.get(i)));
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        SparseBooleanArray arr = listView.getCheckedItemPositions();
        for (int i = 0; i < arr.size(); i++) {
            int pos = arr.keyAt(i);
            if (arr.valueAt(i) && pos >= 0 && pos < pkgs.size()) {
                sb.append(pkgs.get(pos)).append(",");
            }
        }

        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("master", cbMaster.isChecked())
                .putBoolean("global", cbGlobal.isChecked())
                .putString("targets", sb.toString())
                .commit();

        Toast.makeText(this, "已保存，重启游戏魔盒后生效", Toast.LENGTH_LONG).show();
    }
}
