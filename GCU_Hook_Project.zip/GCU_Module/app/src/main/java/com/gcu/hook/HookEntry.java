package com.gcu.hook;

import java.lang.reflect.Method;
import java.util.HashSet;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * vivo 游戏魔盒 超分/插帧 放行控制器
 * 仅对用户在界面里勾选的 App 放行
 */
public class HookEntry implements IXposedHookLoadPackage {

    private static final String TAG    = "GCU";
    private static final String TARGET = "com.vivo.gamecube";
    private static final String SELF   = "com.gcu.hook";

    private static final String UTILS = "com.vivo.gameassistant.utils.e0";
    private static final String CFG   = "com.vivo.common.a";
    private static final String H0    = "com.vivo.common.utils.h0";
    private static final String VSR   = "com.vivo.gameassistant.superresolution.q";
    private static final String LIVE  = "se.j";

    private boolean master = true;
    private boolean global = false;
    private final HashSet<String> targets = new HashSet<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!TARGET.equals(lp.packageName)) return;

        loadConfig();
        XposedBridge.log(TAG + ": 注入 " + lp.processName
                + " | master=" + master
                + " global=" + global
                + " targets=" + targets.size());

        if (!master) {
            XposedBridge.log(TAG + ": 总开关关闭，不挂 Hook");
            return;
        }

        ClassLoader cl = lp.classLoader;

        // ===== 设备级（无包名参数）=====
        forceAll(CFG, "Y0", cl, Boolean.TRUE);   // MEMC 硬件特性
        forceAll(CFG, "H1", cl, Boolean.TRUE);   // 全局能力
        forceAll(UTILS, "l1", cl, Boolean.TRUE); // PD2307/PD2329
        forceAll(UTILS, "m1", cl, Boolean.TRUE); // PD2307/PD2329 + pubgmhd

        // ===== 白名单 / 可用性 =====
        forceByPkg(UTILS, "a1", cl, 1, Boolean.TRUE);  // a1(Context, pkg)
        forceByPkg(UTILS, "E0", cl, 1, Boolean.TRUE);  // E0(Context, pkg)
        forceByPkg(UTILS, "o0", cl, 0, Boolean.TRUE);  // o0(pkg)
        forceByPkg(UTILS, "p0", cl, 0, Boolean.TRUE);  // p0(pkg)

        // ===== 机型门 / 游戏门 =====
        forceByPkg(UTILS, "F0", cl, 0, Boolean.TRUE);
        forceByPkg(UTILS, "z0", cl, 0, Boolean.TRUE);
        forceByPkg(UTILS, "l0", cl, 1, Boolean.TRUE);  // l0(quality, pkg)
        forceByPkg(UTILS, "g1", cl, 0, Boolean.TRUE);
        forceByPkg(UTILS, "P0", cl, 0, Boolean.TRUE);
        forceByPkg(UTILS, "t0", cl, 0, Boolean.TRUE);

        // ===== VSR 白名单字符串 =====
        forceByPkg(VSR, "f", cl, 0, Boolean.TRUE);

        // ===== 状态读取 =====
        forceByPkg(H0, "j", cl, 1, Boolean.TRUE);          // j(Context, pkg) -> true
        forceByPkg(H0, "e", cl, 1, Integer.valueOf(2));    // e(Context, pkg) -> 2 极客态

        // ===== 反向：直播冲突拦截器 -> false =====
        forceByPkg(LIVE, "d", cl, 0, Boolean.FALSE);

        XposedBridge.log(TAG + ": 全部 Hook 已挂载");
    }

    private void loadConfig() {
        try {
            XSharedPreferences p = new XSharedPreferences(SELF, "config");
            p.reload();
            master = p.getBoolean("master", true);
            global = p.getBoolean("global", false);
            String raw = p.getString("targets", "");
            targets.clear();
            if (raw != null) {
                for (String s : raw.split(",")) {
                    s = s.trim();
                    if (s.length() > 0) targets.add(s);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": 读配置失败 " + t);
        }
    }

    private boolean allow(Object pkgObj) {
        if (pkgObj == null) return false;
        String p = String.valueOf(pkgObj);
        if (p.length() == 0) return false;
        if (global) return true;
        return targets.contains(p);
    }

    /** 无包名参数：直接强制返回 */
    private void forceAll(String clsName, String methodName, ClassLoader cl, final Object ret) {
        try {
            Class<?> c = XposedHelpers.findClass(clsName, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(methodName)) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        param.setResult(ret);
                    }
                });
                n++;
            }
            XposedBridge.log(TAG + (n > 0 ? ": OK   " : ": MISS ") + methodName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": FAIL " + methodName + " -> " + t);
        }
    }

    /** 带包名参数：仅包名被勾选时强制返回 */
    private void forceByPkg(String clsName, String methodName, ClassLoader cl,
                            final int pkgIdx, final Object ret) {
        try {
            Class<?> c = XposedHelpers.findClass(clsName, cl);
            int n = 0;
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(methodName)) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        Object pkg = (pkgIdx < param.args.length) ? param.args[pkgIdx] : null;
                        if (allow(pkg)) param.setResult(ret);
                    }
                });
                n++;
            }
            XposedBridge.log(TAG + (n > 0 ? ": OK   " : ": MISS ") + methodName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": FAIL " + methodName + " -> " + t);
        }
    }
}
